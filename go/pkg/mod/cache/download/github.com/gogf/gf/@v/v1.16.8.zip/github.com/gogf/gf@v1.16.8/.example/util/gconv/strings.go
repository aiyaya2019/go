package main

import (
	"fmt"

	"github.com/gogf/gf/util/gconv"
)

func main() {
	fmt.Println(gconv.Strings([]int{1, 2, 3}))
}
