package main

import (
	"fmt"

	"github.com/gogf/gf/frame/g"
)

func main() {
	fmt.Println(g.Config().Get("none"))
}
